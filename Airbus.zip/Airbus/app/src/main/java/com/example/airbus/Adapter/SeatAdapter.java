package com.example.airbus.Adapter;

import static android.app.PendingIntent.getActivity;

import android.annotation.SuppressLint;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.airbus.Activity.SeatListActivity;
import com.example.airbus.Model.Seat;
import com.example.airbus.R;
import com.example.airbus.databinding.SeatItemBinding;

import java.util.ArrayList;
import java.util.List;

public class SeatAdapter extends RecyclerView.Adapter<SeatAdapter.SeatViewholder> {
    private final List<Seat> seatList;
    @SuppressLint("RestrictedApi")
    private final SeatListActivity context;
    private final ArrayList<String> selectedSeatName=new ArrayList<>();
    private final SelectedSeat selectedSeat;

    public SeatAdapter(List<Seat> seatList, @SuppressLint("RestrictedApi") SeatListActivity context, SelectedSeat selectedSeat) {
        this.seatList = seatList;
        this.context = context;
        this.selectedSeat = selectedSeat;
    }

    @NonNull
    @Override
    public SeatAdapter.SeatViewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        SeatItemBinding binding=SeatItemBinding.inflate(LayoutInflater.from(parent.getContext()),parent,false);
        return new SeatViewholder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull SeatViewholder holder, @SuppressLint("RecyclerView") int position) {
    Seat seat=seatList.get(position);
    holder.binding.seatImageView.setText(seat.getName());
    
    switch (seat.getStatus()){
        case AVAILABLE:
            holder.binding.seatImageView.setBackgroundResource(R.drawable.ic_seat_available);

            holder.binding.seatImageView.setTextColor(holder.binding.seatImageView.getContext().getResources().getColor(R.color.white));

            break;
        case SELECTED:
            holder.binding.seatImageView.setBackgroundResource(R.drawable.ic_seat_selected);

            holder.binding.seatImageView.setTextColor(holder.binding.seatImageView.getContext().getResources().getColor(R.color.black));

            break;
        case UNAVAILABLE:
            holder.binding.seatImageView.setBackgroundResource(R.drawable.ic_seat_unavailable);
            holder.binding.seatImageView.setTextColor(holder.binding.seatImageView.getContext().getResources().getColor(R.color.grey));

            break;
        case EMPTY:
            holder.binding.seatImageView.setBackgroundResource(R.drawable.ic_seat_empty);
            holder.binding.seatImageView.setTextColor(Color.parseColor("#00000000"));
            break;
    }
    holder.binding.seatImageView.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if (seat.getStatus()== Seat.SeatStatus.AVAILABLE) {
                seat.setStatus(Seat.SeatStatus.SELECTED);
                selectedSeatName.add(seat.getName());
                SeatAdapter.this.notifyItemChanged(position);
            } else {
                if (seat.getStatus() == Seat.SeatStatus.SELECTED) {
                    seat.setStatus(Seat.SeatStatus.AVAILABLE);
                    selectedSeatName.remove(seat.getName());
                    SeatAdapter.this.notifyItemChanged(position);
                }
            }

            String selected = selectedSeatName.toString()
                    .replace("[", "")
                    .replace("]", "")
                    .replace(" ", "");

            selectedSeat.Return(selected, selectedSeatName.size());
        }
    });
    }


    @Override
    public int getItemCount() {
        return seatList.size();
    }

    @SuppressLint("RestrictedApi")
    public SeatListActivity getContext() {
        return context;
    }

    public static class SeatViewholder extends RecyclerView.ViewHolder {
        SeatItemBinding binding;
        public SeatViewholder(@NonNull SeatItemBinding binding) {
            super(binding.getRoot());
            this.binding=binding;
        }
    }
    public interface  SelectedSeat{
        void Return(String selectedName,int num);
    }
}
