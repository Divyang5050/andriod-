package com.example.airbus.Activity;


import android.annotation.SuppressLint;
import android.content.Intent;
import android.icu.text.DecimalFormat;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.Toast;

import androidx.recyclerview.widget.GridLayoutManager;

import com.example.airbus.Adapter.SeatAdapter;
import com.example.airbus.Model.Flight;
import com.example.airbus.Model.Seat;
import com.example.airbus.R;
import com.example.airbus.databinding.ActivitySeatListBinding;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SeatListActivity extends BaseActivity {
private ActivitySeatListBinding binding;
private Flight flight;
private Double price=0.0;
private final int num = 0;
    private com.example.airbus.Model.Flight Flight;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding=ActivitySeatListBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        getIntentExtra();
        initSeatList();
        setVariable();

    }

    private void setVariable() {
        binding.backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        binding.confimBtn.setOnClickListener((View v) -> {
            startActivity(new Intent(SeatListActivity.this, TicketDetailActivity.class));
        });
//        binding.confimBtn.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                if(num>0){
//                    flight.setPassenger(binding.nameSeatSelectedTxt.getText().toString());
//                    flight.setPrice(price);
//                    Integer intent =new Integer( SeatListActivity.this, TicketDetailActivity.class);
//                    intent.putExtra("flight",flight);
//                    startActivity(intent);
//                }else {
//                    Toast.makeText(SeatListActivity.this,"Please select your seat",Toast.LENGTH_SHORT).show();
//                }
//            }
//        });
    }

    private void initSeatList() {
        GridLayoutManager gridLayoutManager=new GridLayoutManager(this,7);
        gridLayoutManager.setSpanSizeLookup(new GridLayoutManager.SpanSizeLookup(){
            @Override
            public int getSpanSize(int position){
                int i = (position % 7 == 3) ? 1 : 1;
                return i;
            }

        });
        binding.seatRecycleview.setLayoutManager(gridLayoutManager);
        List<Seat> seatList=new ArrayList<>();
        int row=0;


        Map<Integer, String> seatAlphabetMap=new HashMap<>();
        seatAlphabetMap.put(0,"A");
        seatAlphabetMap.put(1,"B");
        seatAlphabetMap.put(2,"C");
        seatAlphabetMap.put(4,"D");
        seatAlphabetMap.put(5,"E");

//        int numberSeat;
//        numberSeat = com.example.airbus.Model.Flight.getNumberSeat() + (com.example.airbus.Model.Flight.getNumberSeat() / 7) + 1;
//        for(int i=0;i<numberSeat;i++){
//            if(i%7==0){
//                row++;
//            }
//            if(i%7==3){
//                seatList.add(new Seat(Seat.SeatStatus.EMPTY,String.valueOf(row)));
//            }else{
//                String seatName=seatAlphabetMap.get(i%7)+row;
//                Seat.SeatStatus seatStatus=flight.getReservedSeats().contains(seatName)?Seat.SeatStatus.UNAVAILABLE: Seat.SeatStatus.AVAILABLE;
//                seatList.add(new Seat(seatStatus, seatName));
//            }
//        }
            SeatAdapter seatAdapter=new SeatAdapter(seatList,this, new SeatAdapter.SelectedSeat() {

                private int num;

                @SuppressLint("SetTextI18n")
                @Override
            public void Return(String selectedName, int num) {
                binding.numberSelectedTxt.setText(num+" Seat Selected");
                binding.nameSeatSelectedTxt.setText(selectedName);
                DecimalFormat df=new DecimalFormat("#.##");
                price=(Double.valueOf(df.format(num+flight.getPrice())));
                this.num = num;
                binding.priceTxt.setText("$"+ price);
            }
        });
        binding.seatRecycleview.setAdapter(seatAdapter);
        binding.seatRecycleview.setNestedScrollingEnabled(false);
    }

    private void getIntentExtra() {
        flight= (Flight)getIntent().getSerializableExtra("flight");
    }
}